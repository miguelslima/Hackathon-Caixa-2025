import { FlatList } from "react-native";
import styled from "styled-components/native";
import { Parcel } from ".";

export const Container = styled.View`
  flex: 1;
  background-color: ${({ theme }) => theme.COLORS.CAIXA_BLUE};
  
`;

export const ContentWrapper = styled.ScrollView`
  padding: 24px;
`;

export const InfoContainer = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

export const InfoTitle = styled.Text`
  font-size: 20px;
  color: #fff;
  text-align: center;

`;

export const SummaryCard = styled.View`
  background-color: #fff;
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
  shadow-color: #000;
  shadow-offset: 0px 2px;
  shadow-opacity: 0.1;
  shadow-radius: 4px;
  elevation: 3;


`;

export const SummaryTitle = styled.Text`
  font-size: 20px;
  font-weight: bold;
  color: ${({ theme }) => theme.COLORS.CAIXA_BLUE};
  margin-bottom: 10px;

  text-align: center;
`;

export const SummaryText = styled.Text`
  font-size: 16px;
  color: #666;
  margin-bottom: 5px;
`;

export const AmortizationContainer = styled.View`
  flex-direction: row;
  justify-content: space-around;
  margin-top: 20px;
`;

export const AmortizationButton = styled.TouchableOpacity`
  background-color: ${({ theme }) => theme.COLORS.CAIXA_YELLOW};
  padding: 16px;
  border-radius: 8px;
  align-items: center;
`;

export const AmortizationButtonText = styled.Text`
  color: #fff;
  font-size: 24px;

  text-align: center;
`;

export const ModalContent = styled.View`
  flex: 1;
  justify-content: space-between;
  background-color: white;
  padding: 20px;
  border-radius: 12px;
  shadow-color: #000;
  shadow-offset: 0px 2px;
  shadow-opacity: 0.25;
  shadow-radius: 4px;
  elevation: 5;
  width: 95%;
  max-height: 95%;
`;

export const CloseButton = styled.TouchableOpacity`
  position: absolute;
  top: 15px;
  right: 15px;
  padding: 10px;
  z-index: 10;
`;

export const ModalTitle = styled.Text`
  font-size: 24px;
  font-weight: bold;
  color: ${({ theme }) => theme.COLORS.CAIXA_BLUE};
`;

export const ModalTable = styled(FlatList<Parcel>).attrs({
  contentContainerStyle: { paddingBottom: 20 },
})`
  width: 100%;
  max-height: 45%; 
`;

export const TableRow = styled.View`
  flex-direction: row;
  justify-content: space-between;
  border-bottom-width: 1px;
  border-bottom-color: #eee;
  padding-vertical: 6px;
  
`;

export const TableHeader = styled.Text`
  font-weight: bold;
  font-size: 12px;
  color: #333;

`;

export const TableCell = styled.Text`
  font-size: 12px;
  color: #666;

  
`;

export const FooterButtons = styled.View`
  margin-top: 20px;
  padding-horizontal: 24px;
  padding-bottom: 24px;
`;
