export default [
  {
    id: '1',
    title: 'Empréstimo para você',
    body: 'Conte com a CAIXA para realizar seus sonhos. Conheça as linhas de crédito para gastar com o que você quiser e precisar. A CAIXA Tem: Crédito Consignado, Penhor, Antecipação de valores a receber como o o 13º salário, o saque aniversário do FGTS e a restituição do imposto de renda, Crédito pré-aprovado, Possibilidade de uso da sua casa ou do seu automóvel como garantia'
  },
  {
    id: '2',
    title: 'Financiamentos para você',
    body: 'A CAIXA tem várias opções de financiamentos, uma ideal para você. Com a CAIXA você pode, Conquistar a sua casa própria, Conquistar o seu automóvel novo, Financiar energia solar na sua casa e contribuir com o meio ambiente, Se tornar um universitário, Conquista de autonomia para pessoa com deficiência',
  },
  {
    id: '3',
    title: 'Crédito CAIXA TEM',
    body: 'A CAIXA apoia o empreendedorismo e oferece ao Empreendedor Pessoa Física e ao MEI uma nova oportunidade para iniciar, ampliar ou melhorar o seu negócio.',
  },
  {
    id: '4',
    title: 'Agro CAIXA',
    body: 'Conte com a parceria da CAIXA. Soluções para todos os clientes. Do Agricultor familiar à Agroindústria.',
  },
  {
    id: '5',
    title: 'Para o seu negócio',
    body: 'Na CAIXA, o empreendedor encontra muitas soluções. Faça sua empresa crescer com financiamento de capital de giro, antecipação de receita e outros recursos.',
  }
]